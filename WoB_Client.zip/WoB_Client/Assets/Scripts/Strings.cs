﻿using UnityEngine;

public class Strings {

	public static readonly string NO_MSG = "";
	public static readonly string ADD = "Add";
	public static readonly string CLEAR = "Clear";
	public static readonly string INPUT = "Input";
	public static readonly string GRAPH = "Graph";
	public static readonly string TOGGLE = "Toggle";
	public static readonly string LEGEND = "Legend";
	public static readonly string SHOW_ITEMS = "Show Items";
	public static readonly string HIDE_ITEMS = "Hide Items";
}