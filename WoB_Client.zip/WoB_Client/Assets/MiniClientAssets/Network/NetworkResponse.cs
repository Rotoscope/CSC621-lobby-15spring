namespace MiniClient {
public abstract class NetworkResponse {
	
	protected short protocol_id;
		
	public short GetID() {
		return protocol_id;
	}
}
}